# `etoolbox`: e-TeX tools for LaTeX

The `etoolbox` package is a toolbox of programming facilities geared
primarily towards LaTeX class and package authors. It provides LaTeX
frontends to some of the primitives provided by e-TeX as well as
some generic tools which are not related to e-TeX but match the
profile of this package.

